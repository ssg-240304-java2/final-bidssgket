package com.ssg.bidssgket.user.domain.payment.domain.enums;

public enum PaymentType {

    // 카카오페이, 비스킷페이
    KAKAO_PAY, BISCUIT_PAY
}
