package com.ssg.bidssgket.user.domain.payment.domain.enums;

public enum PaymentStatus {

    // 결제완료, 결제취소
    PAID, PAYMENT_CANCELLED
}
