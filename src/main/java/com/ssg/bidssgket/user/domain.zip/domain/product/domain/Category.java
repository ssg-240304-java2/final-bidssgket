package com.ssg.bidssgket.user.domain.product.domain;

public enum Category {
    tradingCard,
    uniform,
    shoes,
    artToy,
    watch,
    bag,
    camera,
    interior;

}
