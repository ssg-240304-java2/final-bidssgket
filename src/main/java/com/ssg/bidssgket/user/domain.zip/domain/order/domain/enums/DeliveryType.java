package com.ssg.bidssgket.user.domain.order.domain.enums;

public enum DeliveryType {

    // 직거래, 안전거래
    IN_PERSON, ESCROW
}
