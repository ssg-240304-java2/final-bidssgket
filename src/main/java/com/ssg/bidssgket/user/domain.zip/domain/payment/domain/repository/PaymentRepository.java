package com.ssg.bidssgket.user.domain.payment.domain.repository;

public interface PaymentRepository {
}
