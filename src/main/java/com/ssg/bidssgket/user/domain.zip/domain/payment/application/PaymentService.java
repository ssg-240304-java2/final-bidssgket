package com.ssg.bidssgket.user.domain.payment.application;

public class PaymentService {
}
