package com.ssg.bidssgket.user.domain.member.application;

public class MemberService {
}
