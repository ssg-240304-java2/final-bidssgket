package com.ssg.bidssgket.user.domain.order.domain.enums;

public enum TransactionType {

    AUCTION, DIRECT_PURCHASE // 경매, 즉시 구매
}
