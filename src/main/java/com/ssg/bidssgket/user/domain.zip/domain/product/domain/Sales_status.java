package com.ssg.bidssgket.user.domain.product.domain;

public enum Sales_status {
    selling,
    trading,
    sale_completed,
    sale_pause;
}
