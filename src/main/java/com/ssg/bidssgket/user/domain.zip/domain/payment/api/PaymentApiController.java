package com.ssg.bidssgket.user.domain.payment.api;

public class PaymentApiController {
}
