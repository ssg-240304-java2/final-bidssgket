package com.ssg.bidssgket.user.domain.auction.api;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuctionApiController {
}
