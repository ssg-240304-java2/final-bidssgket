package com.ssg.bidssgket.user.domain.order.domain.repository;

public interface OrderRepository {
}
