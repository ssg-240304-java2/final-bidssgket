package com.ssg.bidssgket.user.domain.order.domain.enums;

public enum DeliveryStatus {

    // 배송대기, 배송중, 배송완료
    PENDING_SHIPMENT, IN_TRANSIT, DELIVERED
}
