package com.ssg.bidssgket.user.domain.payment.domain.enums;

public enum PayChangeType {

    // 입금, 출금
    DEPOSIT, WITHDRAWAL
}
