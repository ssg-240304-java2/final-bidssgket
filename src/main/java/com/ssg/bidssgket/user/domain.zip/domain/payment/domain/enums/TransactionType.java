package com.ssg.bidssgket.user.domain.payment.domain.enums;

public enum TransactionType {

    // 입금, 출금
    DEPOSIT, WITHDRAWAL
}
