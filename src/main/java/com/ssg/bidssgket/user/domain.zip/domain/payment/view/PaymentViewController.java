package com.ssg.bidssgket.user.domain.payment.view;

public class PaymentViewController {
}
