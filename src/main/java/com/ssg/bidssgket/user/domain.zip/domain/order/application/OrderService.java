package com.ssg.bidssgket.user.domain.order.application;

public class OrderService {
}
