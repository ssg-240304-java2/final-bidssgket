package com.ssg.bidssgket.user.domain.member.view;

import com.ssg.bidssgket.user.domain.member.domain.Member;
import com.ssg.bidssgket.user.domain.member.domain.Review;

public class MemberViewController {

//    public void test() {
//        Review review = Review.builder().comment("안녕").reviewer(new Member("")).reviewed()
//    }
}
