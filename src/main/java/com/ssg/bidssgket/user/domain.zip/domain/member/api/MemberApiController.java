package com.ssg.bidssgket.user.domain.member.api;

public class MemberApiController {
}
